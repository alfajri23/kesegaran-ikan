# Kesegaran Mata Ikan > 2023-09-24 10:08am
https://universe.roboflow.com/kesegaran-ikan-fo9x5/kesegaran-mata-ikan-tsp53

Provided by a Roboflow user
License: CC BY 4.0

