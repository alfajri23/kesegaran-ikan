# fish-eye-classification > 2023-09-19 9:35pm
https://universe.roboflow.com/kesegaran-ikan-fo9x5/fish-eye-classification

Provided by a Roboflow user
License: CC BY 4.0

